<?php
$language = "php8";
switch ($language){
case "c++":
    echo "C++ is my favourite language";
    break;

case "c":
     echo "C is my favourite language";
     break;

case "python":
    echo "C++ is my favourite language";
    break;

case "php8":
    echo "C++ is my favourite language";
    break;

    default:
    echo "your favourite language is neither C,php,nor C++";






}







?>