<?php
$colors = ["red","green","yellow","black","blue"]; //index array

$colors[5] = "brown";

// echo $colors [5];

// echo "<br>";

// print_r ($colors);
// echo "<pre>";

//Associative array

// $student_data=[
//     "name"=>"samrah",
//     "age"=>21,
//     "email" => "samrah@gmail.com"
// ];

// update
// $student_data["name"];
// echo $student_data ["name"]."<br>"

// foreach($student_data as $values){
//     echo $values."<br>"
// }

// foreach($student_data as $values){
//     echo "name:" .$values["name"] . "<br>";
//     echo "age:" .$values["age"] . "<br>";
//     echo "email:" .$values["email"] . "<br><br>";
// }




?>